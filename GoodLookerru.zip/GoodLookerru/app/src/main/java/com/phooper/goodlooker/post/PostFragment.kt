package com.phooper.goodlooker.post

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import com.phooper.goodlooker.R
import kotlinx.android.synthetic.main.post_fragment.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.jsoup.Jsoup
import java.io.IOException

class PostFragment : Fragment() {
    val key = "1"

    companion object {
        fun newInstance(linkPost: String) = PostFragment().apply {
            arguments = Bundle().apply {
                putString(key, linkPost)
            }
        }
    }

    private lateinit var viewModel: PostViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.post_fragment, container, false)
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(PostViewModel::class.java)
        // TODO: Use the ViewModel

//linkPost.text = arguments?.getString(key)
        val url = arguments?.getString(key)
       GlobalScope.launch {
            try {
                val document = Jsoup.connect(url).get()
                val elements = document.select("section[class=left-content_vn]")

                val tmp = elements.select("div[class=post]")
                    .select("p")
                    .text()
                GlobalScope.launch(Dispatchers.Main) {
                    linkPost?.text = tmp
                }
            } catch (e: IOException) {
            }
        }

    }
}

