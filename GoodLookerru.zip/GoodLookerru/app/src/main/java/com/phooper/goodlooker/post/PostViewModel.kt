package com.phooper.goodlooker.post

import androidx.lifecycle.ViewModel;

class PostViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
