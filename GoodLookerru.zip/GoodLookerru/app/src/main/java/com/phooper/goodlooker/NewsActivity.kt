package com.phooper.goodlooker

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.phooper.goodlooker.list.ListNewsFragment
import kotlinx.android.synthetic.main.activity_news.*


class NewsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news)

        this.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.host_fragment, ListNewsFragment())
                .commit()
        }

        bottom_navigation_view.setTextVisibility(true)
        bottom_navigation_view.enableAnimation(false)
        bottom_navigation_view.enableItemShiftingMode(false)
        bottom_navigation_view.enableShiftingMode(false)
        for (i in 0 until bottom_navigation_view.menu.size()) {
            bottom_navigation_view.setIconTintList(i, null)
        }
    }

}
