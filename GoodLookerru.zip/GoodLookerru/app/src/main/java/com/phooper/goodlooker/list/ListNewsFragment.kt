package com.phooper.goodlooker.list

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.phooper.goodlooker.R
import com.phooper.goodlooker.post.PostFragment
import kotlinx.android.synthetic.main.list_news_fragment.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.jsoup.Jsoup
import java.io.IOException


class ListNewsFragment : Fragment() {

    private val TAG = "ListNewsFragment"
    private val url = "https://goodlooker.ru/category/uprazhneniya/page/"
    private var page = 1
    private val listNews = mutableListOf<News>()
    private lateinit var adapter: DataAdapter
    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var viewModel: ListNewsViewModel

    companion object {
        fun newInstance() {

        }

    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return inflater.inflate(R.layout.list_news_fragment, container, false)
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(ListNewsViewModel::class.java)
        // TODO: Use the ViewModel


        layoutManager = LinearLayoutManager(context)
        adapter = DataAdapter()
        rv.layoutManager = layoutManager
        rv.adapter = adapter

        adapter.onItemClick = { news ->
            fragmentManager?.beginTransaction()!!
                .addToBackStack(null)
                .setCustomAnimations(
                    R.anim.slide_in_left,
                    R.anim.slide_out_right,
                    R.anim.slide_in_left,
                    R.anim.slide_out_right
                )
                .add(R.id.host_fragment, PostFragment.newInstance(news.linkPost))
                .commit()
//разобрать с detach(), attach()
        }

        GlobalScope.launch {
            getData()
        }

        swipe_refresh_layout.setOnRefreshListener {
            spin_kit.isVisible = true
            swipe_refresh_layout.isRefreshing = false
            page = 1
            listNews.clear()
            GlobalScope.launch {
                /*                while (isInternetAvaible()) {
                                    delay(1000)
                               }*/
                getData()
            }
        }

    }

    override fun onResume() {
        super.onResume()
        addOnScrollListener()
    }

    private fun getData() {
        try {
            val document = Jsoup.connect(url + page.toString()).get()
            val element = document.select("article[class=item-cat_site],[class=item-cat_site last-element]")
            lateinit var date: String
            for (i in 0 until element.size) {
                val title = element.select("div[class=title-cat_site]")
                    .select("span")
                    .eq(i)
                    .text()

                val linkImage =
                    element.select("div[class=thumb-cat_site]")
                        .select("img")
                        .eq(i)
                        .attr("src")

                val linkPost =
                    element.select("div[class=thumb-cat_site]")
                        .select("a")
                        .eq(i)
                        .attr("href")

                val tmpDate = element.select("article[class=item-cat_site]")
                    .select("meta[itemprop=datePublished],meta[itemprop=dateModified]")
                    .eq(i)
                    .attr("content")
                tmpDate.substring(0, 10).replace("-", ".")
                val builder = StringBuilder()
                builder.append(tmpDate.substring(8, 10))
                builder.append(".${tmpDate.substring(5, 7)}")
                builder.append(".${tmpDate.substring(0, 4)}")
                date = builder.toString()

                val comments = element.select("div[class=meta-st-item_posts]")
                    .select("div[class=comments-st_posts]")
                    .eq(i)
                    .text()

                val views = element.select("div[class=meta-st-item_posts]")
                    .select("div[class=views-st_posts]")
                    .eq(i)
                    .text()

                listNews.add(News(title, date, comments, views, linkImage, linkPost))
            }
            GlobalScope.launch(Dispatchers.Main) {
                adapter.set(listNews)
                spin_kit.isVisible = false
            }

        } catch (e: IOException) {
        }



    }

    private fun isInternetAvaible(): Boolean {
        TODO("Реализовать проверку")

    }

    private fun addOnScrollListener() {
        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                if (dy > 0) {
                    val total = recyclerView.layoutManager!!.itemCount
                    val lastVisibleItem = layoutManager.findLastVisibleItemPosition()
                    Log.d("total: $total", " last: ${lastVisibleItem + 1}")
                    if (lastVisibleItem + 1 == total) {
                        rv.clearOnScrollListeners()
                        spin_kit.isVisible = true
                        page++
                        GlobalScope.launch {
                            getData()
                            addOnScrollListener()
                        }
                    }
                }
            }
        })
    }
}




