package com.phooper.goodlooker.list

data class News(
    val title: String,
    val date: String,
    val comments: String,
    val views: String,
    val linkImage: String,
    val linkPost: String

)