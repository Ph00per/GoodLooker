package com.phooper.goodlooker.list

import androidx.lifecycle.ViewModel;

class ListNewsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
