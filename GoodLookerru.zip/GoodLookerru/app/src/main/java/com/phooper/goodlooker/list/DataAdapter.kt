package com.phooper.goodlooker.list

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.phooper.goodlooker.R
import kotlinx.android.synthetic.main.item.view.*
import javax.inject.Inject

class DataAdapter @Inject constructor() : RecyclerView.Adapter<DataAdapter.ViewHolder>() {
    var onItemClick: ((News) -> Unit)? = null
    var listNews = mutableListOf<News>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.item, parent, false)
        return ViewHolder(view)


    }

    override fun getItemCount() = listNews.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val news = listNews[position]
        holder.title.text = news.title
        holder.date.text = news.date
        Glide.with(holder.itemView.context)
            .load(news.linkImage)
            .into(holder.image)
        holder.linkPost = news.linkPost
        holder.views.text = news.views
        holder.comments.text = news.comments
    }

    fun set(list: MutableList<News>) {
        this.listNews.clear()
        this.listNews.addAll(list)
        notifyDataSetChanged()
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val title = itemView.postTitle
        val date = itemView.postDate
        val image = itemView.postImg
        var linkPost = ""
        var views = itemView.postViews
        var comments = itemView.postComments

        init {
            itemView.setOnClickListener {
                onItemClick?.invoke(listNews[adapterPosition])
            }
        }

    }
}